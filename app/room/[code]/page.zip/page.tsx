



"use client";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import io from "socket.io-client";

const ICE = { iceServers: [{ urls: ["stun:stun.l.google.com:19302"] }] };

export default function RoomPage({ params, searchParams }) {
  const code = decodeURIComponent(params.code);
  const name = searchParams?.name || "Guest";
  const router = useRouter();

  // refs & state
  const socketRef = useRef(null);
  const localVideoRef = useRef(null);
  const localStreamRef = useRef(null);

  const [chatText, setChatText] = useState("");
  const [messages, setMessages] = useState([]);
  const [participants, setParticipants] = useState([]);
  const [peers, setPeers] = useState({}); // { [id]: { pc, stream } }

  const [muted, setMuted] = useState(false);
  const [camOff, setCamOff] = useState(false);

  // stage layout
  const [activeId, setActiveId] = useState("self"); // auto switch by voice
  const [pinnedId, setPinnedId] = useState(null);   // user pin override

  useEffect(() => {
    const socket = io();
    socketRef.current = socket;

    const peerConns = new Map();     // id -> RTCPeerConnection
    const audioMonitors = new Map(); // id -> stopFn

    async function ensurePeer(id) {
      if (peerConns.has(id)) return peerConns.get(id);
      const pc = new RTCPeerConnection(ICE);
      peerConns.set(id, pc);

      // add local tracks to new peer
      if (localStreamRef.current) {
        for (const track of localStreamRef.current.getTracks()) {
          pc.addTrack(track, localStreamRef.current);
        }
      }

      pc.onicecandidate = (ev) => {
        if (ev.candidate) socket.emit("ice-candidate", { to: id, candidate: ev.candidate });
      };

      pc.ontrack = (ev) => {
        const [remoteStream] = ev.streams;
        setPeers((prev) => {
          const copy = { ...prev };
          copy[id] = copy[id] || { pc, stream: remoteStream };
          copy[id].stream = remoteStream;
          return copy;
        });
        startAudioMonitor(id, remoteStream);
      };

      return pc;
    }

    async function initMedia() {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });
      localStreamRef.current = stream;
      if (localVideoRef.current) localVideoRef.current.srcObject = stream;
      socket.emit("join", { room: code, name });
      startAudioMonitor("self", stream); // local active speaker
    }

    function startAudioMonitor(id, stream) {
      if (audioMonitors.has(id)) return;
      try {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        const ctx = new AudioCtx();
        const src = ctx.createMediaStreamSource(stream);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 512;
        const data = new Uint8Array(analyser.frequencyBinCount);
        src.connect(analyser);
        let raf;
        const tick = () => {
          analyser.getByteFrequencyData(data);
          const avg = data.reduce((a, b) => a + b, 0) / data.length;
          // threshold টিউন করতে পারো (12-22 ভালো)
          if (avg > 16 && !pinnedId) setActiveId((prev) => (prev !== id ? id : prev));
          raf = requestAnimationFrame(tick);
        };
        tick();
        audioMonitors.set(id, () => {
          cancelAnimationFrame(raf);
          try { src.disconnect(); analyser.disconnect(); ctx.close(); } catch {}
        });
      } catch { /* ignore */ }
    }

    // presence
    socket.on("participants", ({ participants }) => setParticipants(participants));

    // existing peers create offer to newcomer
    socket.on("need-offer", async ({ targetId }) => {
      const pc = await ensurePeer(targetId);
      try {
        const offer = await pc.createOffer({ offerToReceiveAudio: true, offerToReceiveVideo: true });
        await pc.setLocalDescription(offer);
        socket.emit("offer", { to: targetId, sdp: offer });
      } catch (e) { console.error(e); }
    });

    // signaling
    socket.on("offer", async ({ from, sdp }) => {
      const pc = await ensurePeer(from);
      await pc.setRemoteDescription(new RTCSessionDescription(sdp));
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      socket.emit("answer", { to: from, sdp: answer });
    });

    socket.on("answer", async ({ from, sdp }) => {
      const pc = peerConns.get(from);
      if (!pc) return;
      await pc.setRemoteDescription(new RTCSessionDescription(sdp));
    });

    socket.on("ice-candidate", async ({ from, candidate }) => {
      const pc = peerConns.get(from);
      if (!pc) return;
      if (candidate) {
        try { await pc.addIceCandidate(new RTCIceCandidate(candidate)); } catch (e) { console.error(e); }
      }
    });

    socket.on("user-left", ({ id }) => {
      const pc = peerConns.get(id);
      if (pc) {
        pc.getSenders().forEach((s) => s.track && s.track.stop?.());
        pc.close();
      }
      peerConns.delete(id);
      setPeers((prev) => {
        const copy = { ...prev };
        delete copy[id];
        return copy;
      });
    });

    socket.on("chat", (m) => setMessages((prev) => [...prev, m]));

    initMedia();

    return () => {
      try { socket.disconnect(); } catch {}
      for (const pc of peerConns.values()) {
        pc.getSenders().forEach((s) => s.track && s.track.stop?.());
        pc.close();
      }
      peerConns.clear();
      for (const stop of audioMonitors.values()) { try { stop(); } catch {} }
      audioMonitors.clear();
      const ls = localStreamRef.current;
      ls?.getTracks().forEach((t) => t.stop());
    };
  }, [code, name, pinnedId]);

  // controls
  function sendChat(e) {
    e.preventDefault();
    const text = chatText.trim();
    if (!text) return;
    socketRef.current?.emit("chat", { room: code, text });
    setChatText("");
  }
  function toggleMute() {
    const s = localStreamRef.current;
    s?.getAudioTracks().forEach((t) => (t.enabled = !t.enabled));
    setMuted((m) => !m);
  }
  function toggleCam() {
    const s = localStreamRef.current;
    s?.getVideoTracks().forEach((t) => (t.enabled = !t.enabled));
    setCamOff((c) => !c);
  }
  async function shareScreen() {
    try {
      const display = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
      const screenTrack = display.getVideoTracks()[0];

      const senders = [];
      Object.values(peers).forEach((p) => {
        p.pc.getSenders().forEach((s) => { if (s.track && s.track.kind === "video") senders.push(s); });
      });

      const localVideoTrack = localStreamRef.current.getVideoTracks()[0];
      for (const s of senders) await s.replaceTrack(screenTrack);

      const localStream = localStreamRef.current;
      localStream.removeTrack(localVideoTrack);
      localStream.addTrack(screenTrack);
      if (localVideoRef.current) localVideoRef.current.srcObject = localStream;

      screenTrack.onended = async () => {
        const camStream = await navigator.mediaDevices.getUserMedia({ video: true });
        const camTrack = camStream.getVideoTracks()[0];
        for (const s of senders) await s.replaceTrack(camTrack);
        localStream.removeTrack(screenTrack);
        localStream.addTrack(camTrack);
        if (localVideoRef.current) localVideoRef.current.srcObject = localStream;
      };
    } catch (e) { console.error(e); }
  }
  function leaveCall() {
    try { socketRef.current?.disconnect(); } catch {}
    const ls = localStreamRef.current;
    ls?.getTracks().forEach((t) => t.stop());
    router.push("/");
  }

  const stageId = pinnedId || activeId;

  return (
    <div style={{ display: "grid", gridTemplateColumns: "4fr 1fr", gap: 12, padding: 12 }}>
      {/* LEFT: Stage + thumbnails + controls */}
      <div style={{ display: "grid", gridTemplateRows: "minmax(320px, 60vh) auto auto", gap: 12 }}>
        {/* Stage */}
        <div style={{ position: "relative", background: "#000", borderRadius: 12, overflow: "hidden" }}>
          <StageVideo
            activeId={stageId}
            localRef={localVideoRef}
            peers={peers}
            selfLabel={name + " (You)"}
          />
        </div>

        {/* Thumbnails */}
        <div style={{ display: "flex", gap: 10, overflowX: "auto", padding: "6px 2px" }}>
          <ThumbVideoSelf
            localRef={localVideoRef}
            label={name + " (You)"}
            isActive={stageId === "self"}
            onClick={() => setActiveId("self")}
            onPin={() => setPinnedId((p) => (p === "self" ? null : "self"))}
            pinned={pinnedId === "self"}
          />
          {Object.entries(peers).map(([id, p]) => (
            <ThumbVideo
              key={id}
              id={id}
              stream={p.stream}
              label={id.slice(0, 6)}
              isActive={stageId === id}
              onClick={() => setActiveId(id)}
              onPin={() => setPinnedId((prev) => (prev === id ? null : id))}
              pinned={pinnedId === id}
            />
          ))}
        </div>

        {/* Controls */}
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={toggleMute}>{muted ? "Unmute" : "Mute"}</button>
          <button onClick={toggleCam}>{camOff ? "Camera On" : "Camera Off"}</button>
          <button onClick={shareScreen}>Share Screen</button>
          <button
            onClick={leaveCall}
            style={{ marginLeft: "auto", background: "#d33", color: "#fff", border: "none", padding: "8px 12px", borderRadius: 8, fontWeight: 600 }}
          >
            End Call
          </button>
        </div>
      </div>

      {/* RIGHT: Chat + participants */}
      <aside style={{ borderLeft: "1px solid #eee", paddingLeft: 12 }}>
        <h3 style={{ marginTop: 0 }}>Room: {code}</h3>
        <p style={{ marginTop: 0 }}>Participants: {participants.length}</p>

        <div style={{ height: "50vh", overflow: "auto", border: "1px solid #eee", borderRadius: 8, padding: 8, marginBottom: 8 }}>
          {messages.map((m, i) => (
            <div key={i} style={{ marginBottom: 6 }}>
              <b>{m.name || m.from}</b>: {m.text}
            </div>
          ))}
        </div>

        <form onSubmit={sendChat} style={{ display: "flex", gap: 6 }}>
          <input
            value={chatText}
            onChange={(e) => setChatText(e.target.value)}
            placeholder="Type a message"
            style={{ flex: 1, padding: "0.6rem 0.8rem", border: "1px solid #ddd", borderRadius: 8 }}
          />
          <button type="submit">Send</button>
        </form>

        <ul style={{ marginTop: 12, paddingLeft: 18 }}>
          {participants.map((p) => (
            <li key={p.id}>{p.displayName}</li>
          ))}
        </ul>
      </aside>
    </div>
  );
}

/* ====== UI helpers ====== */

// বড় স্টেজ ভিডিও: activeId==='self' হলে লোকাল, নইলে নির্দিষ্ট peer stream
function StageVideo({ activeId, localRef, peers, selfLabel }) {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current) return;
    if (activeId === "self") {
      ref.current.srcObject = localRef.current?.srcObject || null;
    } else {
      const stream = peers[activeId]?.stream || null;
      ref.current.srcObject = stream;
    }
  }, [activeId, peers]);
  const label = activeId === "self" ? selfLabel : (activeId?.slice?.(0, 6) || "");
  return (
    <>
      <video ref={ref} autoPlay playsInline muted={activeId === "self"} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
      <div style={{ position: "absolute", left: 12, bottom: 12, background: "rgba(0,0,0,0.55)", color: "#fff", padding: "4px 10px", borderRadius: 10, fontSize: 13 }}>
        {label}
      </div>
    </>
  );
}

// থাম্ব (peer)
function ThumbVideo({ id, stream, label, isActive, onClick, onPin, pinned }) {
  const ref = useRef(null);
  useEffect(() => { if (ref.current && stream) ref.current.srcObject = stream; }, [stream]);
  return (
    <div
      onClick={onClick}
      style={{
        position: "relative",
        width: 160,
        height: 100,
        borderRadius: 10,
        overflow: "hidden",
        outline: isActive ? "3px solid #3b82f6" : "1px solid #ddd",
        cursor: "pointer",
        background: "#000",
      }}
    >
      <video ref={ref} autoPlay playsInline muted style={{ width: "100%", height: "100%", objectFit: "cover" }} />
      <div style={{ position: "absolute", left: 6, bottom: 6, background: "rgba(0,0,0,0.55)", color: "#fff", padding: "2px 6px", borderRadius: 8, fontSize: 11 }}>
        {label}
      </div>
      <button
        onClick={(e) => { e.stopPropagation(); onPin?.(); }}
        title={pinned ? "Unpin" : "Pin to stage"}
        style={{
          position: "absolute",
          right: 6,
          top: 6,
          fontSize: 11,
          padding: "2px 6px",
          borderRadius: 8,
          border: "none",
          background: pinned ? "#f59e0b" : "rgba(255,255,255,0.85)",
        }}
      >
        {pinned ? "Unpin" : "Pin"}
      </button>
    </div>
  );
}

// থাম্ব (self)
function ThumbVideoSelf({ localRef, label, isActive, onClick, onPin, pinned }) {
  return (
    <div
      onClick={onClick}
      style={{
        position: "relative",
        width: 160,
        height: 100,
        borderRadius: 10,
        overflow: "hidden",
        outline: isActive ? "3px solid #3b82f6" : "1px solid #ddd",
        cursor: "pointer",
        background: "#000",
      }}
    >
      <video ref={localRef} autoPlay playsInline muted style={{ width: "100%", height: "100%", objectFit: "cover" }} />
      <div style={{ position: "absolute", left: 6, bottom: 6, background: "rgba(0,0,0,0.55)", color: "#fff", padding: "2px 6px", borderRadius: 8, fontSize: 11 }}>
        {label}
      </div>
      <button
        onClick={(e) => { e.stopPropagation(); onPin?.(); }}
        title={pinned ? "Unpin" : "Pin to stage"}
        style={{
          position: "absolute",
          right: 6,
          top: 6,
          fontSize: 11,
          padding: "2px 6px",
          borderRadius: 8,
          border: "none",
          background: pinned ? "#f59e0b" : "rgba(255,255,255,0.85)",
        }}
      >
        {pinned ? "Unpin" : "Pin"}
      </button>
    </div>
  );
}

